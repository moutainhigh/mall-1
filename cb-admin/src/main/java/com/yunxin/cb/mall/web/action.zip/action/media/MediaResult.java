package com.yunxin.cb.mall.web.action.media;

/**
 * Created by gonglei on 16/1/25.
 */
public class MediaResult {

    private FileNode fileNode;

    private String result;

    public FileNode getFileNode() {
        return fileNode;
    }

    public void setFileNode(FileNode fileNode) {
        this.fileNode = fileNode;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
